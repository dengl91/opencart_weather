<?php
$_['heading_title'] = 'Weather module';
<?php
$_['heading_title']  = 'Модуль погоды';
$_['text_extension'] = 'Расширения';
$_['text_success']   = 'Настройки успешно изменены!';
$_['text_edit']      = 'Настройки модуля';
